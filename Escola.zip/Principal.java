/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio2;

/**
 *
 * @author Lucas Araújo
 */
public class Principal{
    public static void main(String[] args) {
        Funcionario[] v = {
            new Professor("Ana", 3000, "POO"),
            new Coordenador("Bruno", 4500, "Pedagogico")
        };

        for (int i = 0; i < v.length; i++) {
            System.out.println(v[i].descrever());
        }

        System.out.println(v[0].bonificacao());
        System.out.println(v[0].bonificacao(20));
    }
}
