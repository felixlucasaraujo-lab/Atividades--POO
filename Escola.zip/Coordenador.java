/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio2;

/**
 *
 * @author Lucas Araújo
 */
public class Coordenador extends Funcionario {
    private String setor;

    public Coordenador(String nome, double salario, String setor) {
        super(nome, salario);
        this.setor = setor;
    }

    public String descrever() {
        return "Coordenador: " + nome + ", setor " + setor;
    }
}
