/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio1;

/**
 *
 * @author Lucas Araújo
 */
public class Principal{
    public static void main(String[] args) {
        Animal[] v = {
            new Cachorro("Rex", 3, "Labrador"),
            new Gato("Mia", 2, "curta")
        };

        for (int i = 0; i < v.length; i++) {
            System.out.println(v[i].descrever());
        }

        System.out.println(v[0].idadeEmMeses());
        System.out.println(v[0].idadeEmMeses(6));
    }
}