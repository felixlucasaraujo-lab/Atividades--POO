/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio7;

/**
 *
 * @author Lucas Araújo
 */
public class Principal {
    public static void main(String[] args) {
        Imovel[] v = {
            new Casa("Rua A, 10", 80, 3),
            new Apartamento("Rua B, 200", 60, 5)
        };

        for (int i = 0; i < v.length; i++) {
            System.out.println(v[i].descrever());
        }

        System.out.println(v[0].valorEstimado(3000));
        System.out.println(v[0].valorEstimado(3000, 2000));
    }
}
