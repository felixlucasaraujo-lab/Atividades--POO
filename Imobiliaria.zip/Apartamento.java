/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio7;

/**
 *
 * @author Lucas Araújo
 */
public class Apartamento extends Imovel {
    private int andar;

    public Apartamento(String endereco, double area, int andar) {
        super(endereco, area);
        this.andar = andar;
    }

    public String descrever() {
        return "Apartamento: " + endereco + ", andar " + andar;
    }
}
