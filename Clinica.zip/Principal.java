/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio4;

/**
 *
 * @author Lucas Araújo
 */
public class Principal {
    public static void main(String[] args) {
        Pessoa[] v = {
            new Paciente("Carla", "Unimed"),
            new Medico("Diego", "Clinica")
        };

        for (int i = 0; i < v.length; i++) {
            System.out.println(v[i].ficha());
        }

        System.out.println(v[0].agendar("12/10/2026"));
        System.out.println(v[0].agendar("12/10/2026", "14:00"));
    }
}
