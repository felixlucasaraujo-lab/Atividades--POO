/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio6;

/**
 *
 * @author Lucas Araújo
 */
public class Principal {
    public static void main(String[] args) {
        Item[] v = {
            new Lanche("X-burguer", 18, 2),
            new Bebida("Suco", 8, 300)
        };

        for (int i = 0; i < v.length; i++) {
            System.out.println(v[i].descrever());
        }

        System.out.println(v[0].total());
        System.out.println(v[0].total(2));
    }
}
