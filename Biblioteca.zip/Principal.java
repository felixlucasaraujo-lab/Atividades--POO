/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio5;

/**
 *
 * @author Lucas Araújo
 */
public class Principal{
    public static void main(String[] args) {
        Publicacao[] v = {
            new Livro("Dom Casmurro", 1899, 256),
            new Revista("Ciencia Hoje", 2024, 301)
        };

        for (int i = 0; i < v.length; i++) {
            System.out.println(v[i].citar());
        }

        System.out.println(v[0].emprestar(7));
        System.out.println(v[0].emprestar(7, "Ana"));
    }
}
