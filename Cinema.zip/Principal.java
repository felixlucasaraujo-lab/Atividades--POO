/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio9;

/**
 *
 * @author Lucas Araújo
 */
public class Principal {
    public static void main(String[] args) {
        Ingresso[] v = {
            new MeiaEntrada("Divertida Mente", 40, "carteira 123"),
            new Vip("Duna", 40, "A")
        };

        for (int i = 0; i < v.length; i++) {
            System.out.println(v[i].valorFinal());
        }

        System.out.println(v[0].resumo());
        System.out.println(v[0].resumo(true));
    }
}