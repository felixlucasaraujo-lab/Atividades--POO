/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio9;

/**
 *
 * @author Lucas Araújo
 */
public class Vip extends Ingresso {
    private String setor;

    public Vip(String filme, double valor, String setor) {
        super(filme, valor);
        this.setor = setor;
    }

    public double valorFinal() {
        return valor + 15;
    }
}