/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio9;

/**
 *
 * @author Lucas Araújo
 */
public class MeiaEntrada extends Ingresso {
    private String documento;

    public MeiaEntrada(String filme, double valor, String documento) {
        super(filme, valor);
        this.documento = documento;
    }

    public double valorFinal() {
        return valor / 2;
    }
}
