/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio3;

/**
 *
 * @author Lucas Araújo
 */
public class Caderno extends Produto {
    private int folhas;

    public Caderno(String nome, double preco, int folhas) {
        super(nome, preco);
        this.folhas = folhas;
    }

    public String descrever() {
        return "Caderno: " + nome + ", " + folhas + " folhas";
    }
}
