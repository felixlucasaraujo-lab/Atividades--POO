/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio3;

/**
 *
 * @author Lucas Araújo
 */
public class Principal {
    public static void main(String[] args) {
        Produto[] v = {
            new Caderno("Universitario", 20, 96),
            new Caneta("Bic", 5, "azul")
        };

        for (int i = 0; i < v.length; i++) {
            System.out.println(v[i].descrever());
        }

        System.out.println(v[0].precoComDesconto(10));
        System.out.println(v[0].precoComDesconto(90, 8));
    }
}
