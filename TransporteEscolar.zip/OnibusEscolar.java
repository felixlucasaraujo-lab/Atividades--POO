/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio10;

/**
 *
 * @author Lucas Araújo
 */
public class OnibusEscolar extends Transporte {
    private int monitores;

    public OnibusEscolar(String linha, int monitores) {
        super(linha);
        this.monitores = monitores;
    }

    public String anunciar() {
        return "Onibus da linha " + linha + ", " + monitores + " monitores";
    }
}