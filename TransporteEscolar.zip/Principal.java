/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio10;

/**
 *
 * @author Lucas Araújo
 */
public class Principal {
    public static void main(String[] args) {
        Transporte[] v = {
            new Van("Centro", 15),
            new OnibusEscolar("Bairro", 2)
        };

        for (int i = 0; i < v.length; i++) {
            System.out.println(v[i].anunciar());
        }

        System.out.println(v[0].lotacao(12));
        System.out.println(v[0].lotacao(12, 15));
    }
}
