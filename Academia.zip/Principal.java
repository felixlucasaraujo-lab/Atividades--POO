/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio8;

/**
 *
 * @author Lucas Araújo
 */
public class Principal{
    public static void main(String[] args) {
        Atleta[] v = {
            new Corredor("Lia", 10),
            new Nadador("Paulo", "crawl")
        };

        for (int i = 0; i < v.length; i++) {
            System.out.println(v[i].apresentar());
        }

        System.out.println(v[0].registrarTempo(55.2));
        System.out.println(v[0].registrarTempo(58, "100m"));
    }
}
